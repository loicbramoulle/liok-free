# SPDX-License-Identifier: GPL-3.0-or-later
"""One autosave, Blender's own, kept going while an add-on's modal operator runs (VR sessions of
VR Builder and VR Animate).

Meant for the Liok add-on kit (copied as is into each add-on, never edited by hand there).
Blender's autosave waits while a modal operator runs, and a VR session is one: Blender never
writes its autosave during VR. So while VR runs the add-on writes Blender's own autosave file
itself: the same file (``<name>_<pid>_autosave.blend``, ``<pid>_autosave.blend`` for an unsaved
file), in the same place (the temporary folder of Preferences > File Paths), at Blender's own
interval (Preferences > Save & Load > Auto Save). File > Recover > Auto Save and the crash popup's
Restart find it, Blender removes it on a normal quit. Nothing is ever written next to the work
(liok, 2026-10-20: 20 scenes in a production folder, no autosave folders), the open file is never
touched.

    from . import liok_autosave
    keeper = liok_autosave.Keeper("VR Builder", busy=fn, on_saved=fn, on_error=fn)
    keeper.start()                       # VR starts: the clock starts now (a main loop timer)
    keeper.stop()                        # VR ends
    keeper.last_save()                   # (seconds since the last autosave or None, its path)
    liok_autosave.write()                # Blender's autosave file now -> path (raises on failure)
    liok_autosave.recover_path()         # where it goes
    liok_autosave.settings()             # (on, minutes) of Blender's Auto Save
    liok_autosave.set_settings(on, minutes)   # change them (an add-on's own Autosave toggle)
    liok_autosave.newer_autosave()       # another session's autosave newer than the open file

Write only after a change (kit 3, the SSD Saver add-on): Blender's own autosave rewrites the whole
file every interval while it has unsaved changes, even when nothing happened for hours (a 2 GB
file open for a night: about 1.2 TB written). ``take_over(on)`` turns Blender's own autosave off
for the session and lets the Keepers write only when something changed since the last autosave,
at most ``minutes`` after the first change (the work lost after a crash stays under the interval).
``give_back()`` hands it back to Blender. The state is shared by every copy of this module (driver
namespace), so the VR Keepers of VR Builder and VR Animate follow it: while one runs (foreground),
the background Keeper of SSD Saver waits.

    liok_autosave.take_over(on=True)     # SSD Saver on: Blender's autosave off, writes after a change only
    liok_autosave.give_back()            # Blender's own autosave back (its checkbox as the user wanted)
    liok_autosave.track_changes()        # the handlers that see changes (SSD Saver's register)
    liok_autosave.untrack_changes()
    liok_autosave.state()                # the shared dict (smart, on, first_change, last_write, ...)

Blender's own file (kit 6): outside VR, a background Keeper (SSD Saver) no longer writes a copy:
it turns Blender's own Auto Save on when something changed and off again once Blender wrote it.
Blender's autosave records itself as the last file written, which is what the crash dialog's
Restart reopens (writefile.cc: G.filepath_last_blend); a copy (``save_as_mainfile(copy=True)``)
does not, so Restart reopened the last real save (liok 2026-10-24). In VR Blender's own autosave
never runs (it waits while a modal operator runs): the VR Keepers still write the copy there.

After a crash (kit 5): Blender's crash dialog "Restart" reopens the file as it was last saved,
never an autosave (blenlib system_win32.cc relaunches with the last .blend). ``offer_recover()``
(called in an add-on's register) shows a popup when a file opens and another session's autosave
of it is newer: "Open it" opens that autosave. One popup whatever the number of add-ons.

The copy is written with Smart Eevee's lite materials kept as they are
(``liok_eevee.keep_lite_on_save`` when the add-on has liok_eevee), from a timer of the main
loop, never from inside the VR loop, and waits while ``busy()`` says an action is in progress.
Like Blender's own autosave it writes no thumbnail and no compression: in VR the thumbnail is an
offscreen render of the view, and the save blocks Blender (headset included) while it runs
(2026-10-22, VR Builder: 3 to 9 s). ``last_seconds`` is how long the last write took.
"""
import importlib
import os
import tempfile
import time

import bpy
from bpy.app.handlers import persistent

KIT_FILE_VERSION = 6

CHECK_EVERY = 5.0          # s between two looks at the clock
BUSY_RETRY = 0.2           # s before looking again while busy (the save catches the next pause)
RETRY_FAILED = 30.0        # s before trying again after a failed autosave


def temp_base():
    """Blender's own temporary folder, where its autosaves go and File > Recover > Auto Save looks
    (not ``bpy.app.tempdir``: that is a per-session folder Blender deletes)."""
    base = tempfile.gettempdir()
    try:
        prefs_dir = bpy.context.preferences.filepaths.temporary_directory
        if prefs_dir:
            base = bpy.path.abspath(prefs_dir)
    except Exception:
        pass
    return base


def recover_path(filepath=None, pid=None):
    """Blender's own autosave file of ``filepath`` (the open file by default) for process ``pid``
    (this Blender by default): the one File > Recover > Auto Save opens."""
    path = bpy.data.filepath if filepath is None else filepath
    pid = os.getpid() if pid is None else pid
    stem = os.path.splitext(os.path.basename(path))[0]
    return os.path.join(temp_base(), f"{stem}_{pid}_autosave.blend" if path else f"{pid}_autosave.blend")


SHARED = "liok_autosave_shared"     # driver namespace: one state for every copy of this module
IGNORE_AFTER_LOAD = 3.0             # s of updates after a file opens that are not changes


def state():
    """The autosave state shared by every add-on's copy of this module."""
    ns = bpy.app.driver_namespace
    d = ns.get(SHARED)
    if not isinstance(d, dict):
        d = {"smart": False, "on": True, "first_change": None, "last_write": time.monotonic(),
             "foreground": 0, "ignore_until": 0.0, "frame_tick": False, "ops": None}
        ns[SHARED] = d
    return d


def settings():
    """(on, minutes) of the autosave: Blender's own Auto Save (Preferences > Save & Load), or
    SSD Saver's on / off while it has taken over (Blender's checkbox is then off)."""
    try:
        fp = bpy.context.preferences.filepaths
        d = state()
        on = d["on"] if d["smart"] else bool(fp.use_auto_save_temporary_files)
        return bool(on), max(int(fp.auto_save_time), 1)
    except Exception:
        return True, 2


def set_settings(on=None, minutes=None):
    """Change the autosave (an add-on's Autosave toggle and minutes are Blender's, or SSD Saver's
    on / off while it has taken over). The preferences are marked changed so Blender keeps them.
    True when something changed."""
    try:
        prefs = bpy.context.preferences
        fp = prefs.filepaths
        changed = False
        d = state()
        if on is not None and d["smart"]:
            changed = d["on"] != bool(on)
            d["on"] = bool(on)
            if not on and d.get("native_armed") is not None:
                d["native_armed"] = None
                _blender_toggle(False)      # turned off: Blender's own timer goes too
            on = None
        if on is not None and bool(fp.use_auto_save_temporary_files) != bool(on):
            fp.use_auto_save_temporary_files = bool(on)
            changed = True
        if minutes is not None and int(fp.auto_save_time) != int(minutes):
            fp.auto_save_time = int(minutes)
            changed = True
        if changed:
            prefs.is_dirty = True
        return changed
    except Exception as ex:
        print("liok_autosave: could not set Blender's Auto Save:", ex)
        return False


def _blender_toggle(on):
    """Blender's own Auto Save checkbox, the preferences left as dirty / clean as they were (so a
    session's take over is not written into the user's preferences by itself)."""
    prefs = bpy.context.preferences
    dirty = getattr(prefs, "is_dirty", None)
    if bool(prefs.filepaths.use_auto_save_temporary_files) != bool(on):
        prefs.filepaths.use_auto_save_temporary_files = bool(on)
    if dirty is not None:
        prefs.is_dirty = dirty


def take_over(on=True):
    """Autosave only after a change, for this session: Blender's own timer off (it would rewrite
    the whole file every interval while the file has unsaved changes), the Keepers write instead."""
    d = state()
    d["smart"] = True
    d["on"] = bool(on)
    try:
        _blender_toggle(False)
    except Exception as ex:
        print("liok_autosave: could not turn Blender's own autosave off:", ex)


def give_back():
    """Blender's own autosave back, its checkbox as the user wanted it."""
    d = state()
    if not d["smart"]:
        return
    d["smart"] = False
    d["native_armed"] = None
    try:
        _blender_toggle(d["on"])
    except Exception as ex:
        print("liok_autosave: could not give Blender its autosave back:", ex)


def taken_over():
    return state()["smart"]


def mark_changed():
    """Something in the file changed: an autosave is due ``minutes`` after the first change."""
    d = state()
    if time.monotonic() < d["ignore_until"]:
        return
    if d["first_change"] is None:
        d["first_change"] = time.monotonic()


def changed():
    return state()["first_change"] is not None


def _note_operators():
    """Every operator Blender registers (a sculpt stroke, a transform, a delete) is a change,
    even one that sends no depsgraph update."""
    try:
        ops = bpy.context.window_manager.operators
        key = (len(ops), ops[-1].as_pointer() if len(ops) else 0)
    except Exception:
        return
    d = state()
    if d["ops"] is not None and key != d["ops"]:
        mark_changed()
    d["ops"] = key


@persistent
def _on_depsgraph(scene, depsgraph=None):
    d = state()
    if d["frame_tick"]:              # a frame change (playback, render, scrub) is no edit
        d["frame_tick"] = False
        return
    try:
        if bpy.app.is_job_running('RENDER'):
            return
    except Exception:
        pass
    mark_changed()


@persistent
def _on_frame(*_args):
    state()["frame_tick"] = True


@persistent
def _on_undo(*_args):
    mark_changed()


@persistent
def _on_load(*_args):
    d = state()
    d["first_change"] = None
    d["last_write"] = time.monotonic()
    d["ignore_until"] = time.monotonic() + IGNORE_AFTER_LOAD
    d["ops"] = None


@persistent
def _on_save(*_args):
    """A real save (Ctrl S): nothing to autosave until the next change. (The autosave copies are
    written without handlers.)"""
    d = state()
    d["first_change"] = None
    d["last_write"] = time.monotonic()


_HANDLERS = (("depsgraph_update_post", _on_depsgraph), ("frame_change_pre", _on_frame),
             ("undo_post", _on_undo), ("redo_post", _on_undo), ("load_post", _on_load),
             ("save_post", _on_save))


def track_changes():
    for name, fn in _HANDLERS:
        lst = getattr(bpy.app.handlers, name)
        if fn not in lst:
            lst.append(fn)


def untrack_changes():
    for name, fn in _HANDLERS:
        lst = getattr(bpy.app.handlers, name)
        while fn in lst:
            lst.remove(fn)


def _eevee():
    """The add-on's liok_eevee next to this module, or None."""
    try:
        if __package__:
            return importlib.import_module(__package__ + ".liok_eevee")
        return importlib.import_module("liok_eevee")
    except Exception:
        return None


class _window_override:
    """A window for the save operator, on Blender's live data. After an undo the context of a
    timer can still hold the data the undo freed, and ``temp_override(window=...)`` then fails with
    "Window not found" (kit 4, VR Builder 2026-10-23: every VR autosave failed after an undo).
    The live data first, then the window inside it."""

    def __init__(self, context):
        self._ctx = context

    def __enter__(self):
        self._outer = self._ctx.temp_override(blend_data=bpy.data)
        self._outer.__enter__()
        self._inner = None
        try:
            ctx = bpy.context
            for win in ctx.window_manager.windows:
                if win.screen is not None:
                    self._inner = ctx.temp_override(window=win)
                    break
            if self._inner is not None:
                self._inner.__enter__()
        except Exception:
            self._outer.__exit__(None, None, None)
            raise
        return self

    def __exit__(self, *exc):
        try:
            if self._inner is not None:
                self._inner.__exit__(*exc)
        finally:
            self._outer.__exit__(*exc)
        return False


last_seconds = 0.0         # how long the last write() took


class _fast_save:
    """No thumbnail while an autosave is written (Preferences > Save & Load > File Preview Type
    put back after it, the preferences left unchanged)."""

    def __enter__(self):
        prefs = bpy.context.preferences
        self._dirty = getattr(prefs, "is_dirty", None)
        self._preview = None
        try:
            self._preview = prefs.filepaths.file_preview_type
            if self._preview != 'NONE':
                prefs.filepaths.file_preview_type = 'NONE'
        except (AttributeError, TypeError):
            self._preview = None
        return self

    def __exit__(self, *_exc):
        prefs = bpy.context.preferences
        try:
            if self._preview is not None and prefs.filepaths.file_preview_type != self._preview:
                prefs.filepaths.file_preview_type = self._preview
            if self._dirty is not None:
                prefs.is_dirty = self._dirty
        except (AttributeError, TypeError):
            pass
        return False


class _no_handlers:
    """No save handlers around an autosave, like Blender's own autosave (which calls none): other
    add-ons' save_pre / save_post (syncs, uploads, material swaps) are not run every minute."""
    NAMES = ("save_pre", "save_post", "save_post_fail")

    def __enter__(self):
        self._kept = {}
        for name in self.NAMES:
            lst = getattr(bpy.app.handlers, name, None)
            if lst is not None:
                self._kept[name] = list(lst)
                lst.clear()
        return self

    def __exit__(self, *_exc):
        for name, fns in self._kept.items():
            lst = getattr(bpy.app.handlers, name)
            added = [fn for fn in lst if fn not in fns]     # registered during the save
            lst.clear()
            lst.extend(fns + added)
        return False


def write(path=None, compress=False):
    """Write Blender's autosave file now (a copy, the open file untouched, no thumbnail, no save
    handlers; ``compress``: smaller on the disk, a little longer). Returns its path; raises when
    Blender refuses or nothing reached the disk."""
    global last_seconds
    path = path or recover_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    context = bpy.context
    eevee = _eevee()
    hold = getattr(eevee, "keep_lite_on_save", None) if eevee is not None else None
    started = time.time()
    clock = time.perf_counter()
    with _window_override(context), _fast_save(), _no_handlers():
        if hold is not None:
            with hold():
                result = bpy.ops.wm.save_as_mainfile(filepath=path, copy=True, compress=bool(compress))
        else:
            result = bpy.ops.wm.save_as_mainfile(filepath=path, copy=True, compress=bool(compress))
    last_seconds = time.perf_counter() - clock
    if 'FINISHED' not in result:
        raise RuntimeError(f"Blender refused to write {os.path.basename(path)}")
    try:
        if os.path.getmtime(path) < started - 1.0:
            raise RuntimeError(f"{os.path.basename(path)} unchanged on the disk")
    except OSError:
        raise RuntimeError(f"{os.path.basename(path)} not written") from None
    return path


def autosaves_of(filepath=None):
    """Every Blender autosave of ``filepath`` (the open file by default) in the temporary folder,
    whatever the process (a crashed session had another pid). Unsaved file: this process's only."""
    path = bpy.data.filepath if filepath is None else filepath
    if not path:
        own = recover_path(path)
        return [own] if os.path.exists(own) else []
    stem = os.path.splitext(os.path.basename(path))[0]
    base = temp_base()
    try:
        names = os.listdir(base)
    except OSError:
        return []
    found = []
    for f in names:
        if f.startswith(stem + "_") and f.endswith("_autosave.blend") and f[len(stem) + 1:-15].isdigit():
            found.append(os.path.join(base, f))
    return found


def newer_autosave(filepath=None, slack=1.0):
    """The newest autosave of the open file written by another session (a crash, or a quit
    without saving) when it is newer than the file itself, else None."""
    path = bpy.data.filepath if filepath is None else filepath
    if not path:
        return None
    own = os.path.normcase(os.path.abspath(recover_path(path)))
    others = [p for p in autosaves_of(path) if os.path.normcase(os.path.abspath(p)) != own]
    try:
        latest = max(others, key=os.path.getmtime) if others else None
        if latest and os.path.getmtime(latest) > os.path.getmtime(path) + slack:
            return latest
    except OSError:
        pass
    return None


class Keeper:
    """Blender's autosave kept going while VR runs: ``start()`` when it starts, ``stop()`` when it
    ends. ``busy()`` -> True delays a save (trigger held, a drag...); ``on_saved(path)`` and
    ``on_error(message)`` let the add-on say it in the headset. The interval and the on / off are
    Blender's own Auto Save settings."""

    def __init__(self, name="", busy=None, on_saved=None, on_error=None, background=False, compress=False):
        self.name = name
        self.busy = busy
        self.background = background   # SSD Saver's own: waits while a foreground (VR) Keeper runs
        self.compress = compress
        self._retry_at = 0.0           # after a failed autosave (only after a change: kit 3)
        self.on_saved = on_saved
        self.on_error = on_error
        self.last_time = 0.0       # time.monotonic() of the last autosave (or of start())
        self.last_path = ""
        self.last_error = ""
        self._saved_once = False
        self._running = False
        self._timer = self._tick   # one bound method, so the timer can be found again

    @property
    def running(self):
        return self._running

    def start(self):
        """Begin (the clock starts now)."""
        if not self._running and not self.background:
            state()["foreground"] += 1
        self._running = True
        self.last_time = time.monotonic()
        if not bpy.app.timers.is_registered(self._timer):
            # A background Keeper (SSD Saver) lives across file loads; a VR one ends with its session.
            bpy.app.timers.register(self._timer, first_interval=CHECK_EVERY, persistent=self.background)

    def stop(self):
        if self._running and not self.background:
            d = state()
            d["foreground"] = max(0, d["foreground"] - 1)
        self._running = False
        if bpy.app.timers.is_registered(self._timer):
            bpy.app.timers.unregister(self._timer)

    def due(self):
        on, minutes = settings()
        if not on:
            return False
        d = state()
        if d["smart"]:
            # Only after a change, at most ``minutes`` after the first one (kit 3).
            _note_operators()
            if self.background and d["foreground"] > 0:
                return False
            first = d["first_change"]
            now = time.monotonic()
            return first is not None and now - first >= minutes * 60.0 and now >= self._retry_at
        return time.monotonic() - self.last_time >= minutes * 60.0

    def save_now(self):
        """Write Blender's autosave file now. Returns the path or None (``last_error`` says why)."""
        try:
            path = write(compress=self.compress)
        except Exception as ex:
            text = str(ex).strip()
            self.last_error = text.splitlines()[-1][:120] if text else type(ex).__name__
            print(f"{self.name or 'liok_autosave'}: autosave failed:", ex)
            # Tried again in RETRY_FAILED seconds, not at every look at the clock.
            self.last_time = time.monotonic() - max(settings()[1] * 60.0 - RETRY_FAILED, 0.0)
            self._retry_at = time.monotonic() + RETRY_FAILED
            if self.on_error is not None:
                self.on_error(self.last_error)
            return None
        self.last_time = time.monotonic()
        self.last_path = path
        self.last_error = ""
        self._saved_once = True
        d = state()
        d["last_write"] = self.last_time
        d["first_change"] = None
        if self.on_saved is not None:
            self.on_saved(path)
        return path

    def last_save(self):
        """(seconds since the last autosave or None, its path)."""
        if not self._saved_once:
            return None, self.last_path
        return time.monotonic() - self.last_time, self.last_path

    def _tick(self):
        if not self._running:
            return None
        if self.background and state()["smart"]:
            self._drive_native()
            return CHECK_EVERY
        if not self.due():
            return CHECK_EVERY
        try:
            if self.busy is not None and self.busy():
                return BUSY_RETRY
        except Exception:
            pass
        self.save_now()
        return CHECK_EVERY


    def _drive_native(self):
        """Kit 6, outside VR: Blender's own Auto Save on while a change waits to be autosaved, off
        once Blender wrote its autosave file (its timer counts its interval from the change)."""
        d = state()
        _note_operators()
        path = recover_path()
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            mtime = 0.0
        armed = d.get("native_armed")
        want = bool(d["on"]) and d["foreground"] == 0 and d["first_change"] is not None
        try:
            if armed is not None and mtime > armed[1]:
                # Blender wrote it: nothing waits any more, its timer off until the next change.
                d["first_change"] = None
                d["native_armed"] = None
                d["last_write"] = self.last_time = time.monotonic()
                self.last_path, self.last_error, self._saved_once = path, "", True
                _blender_toggle(False)
                if self.on_saved is not None:
                    self.on_saved(path)
                return
            if want and armed is None:
                d["native_armed"] = (time.monotonic(), mtime)
                _blender_toggle(True)       # Blender's timer starts now: it writes one interval later
            elif not want and armed is not None:
                d["native_armed"] = None
                _blender_toggle(False)
        except Exception as ex:
            print(f"{self.name or 'liok_autosave'}: could not drive Blender's autosave:", ex)


# -- after a crash: the newer autosave offered when the file opens (kit 5) ---------------------------

def _show_offer():
    path = bpy.app.driver_namespace.get("liok_autosave_offer", "")
    if not path or not os.path.exists(path):
        return None
    try:
        wm = bpy.context.window_manager
        if not wm.windows:
            return 0.5
    except Exception:
        return 0.5
    when = time.strftime("%H:%M", time.localtime(os.path.getmtime(path)))
    name = os.path.basename(path)

    def draw(menu, _context):
        layout = menu.layout
        layout.label(text=f"This file has a newer autosave from {when} (Blender crashed or quit without saving).")
        layout.label(text="Blender's Restart reopens the file as last saved, without that work.")
        op = layout.operator("wm.open_mainfile", text=f"Open the autosave ({name})", icon='RECOVER_LAST')
        op.filepath = path
        op.load_ui = False
        layout.label(text="Then File > Save As to keep it.", icon='INFO')

    try:
        with _window_override(bpy.context):
            bpy.context.window_manager.popup_menu(draw, title="Newer autosave found", icon='ERROR')
    except Exception as ex:
        print("liok_autosave: could not show the recover offer:", ex)
    bpy.app.driver_namespace["liok_autosave_offer"] = ""
    return None


@persistent
def _offer_on_load(*_args):
    """A file opened: a newer autosave of it from another session is offered (a timer shows it:
    nothing is written here)."""
    try:
        if bpy.app.background:
            return
        path = newer_autosave()
    except Exception:
        return
    if path:
        bpy.app.driver_namespace["liok_autosave_offer"] = path
        if not bpy.app.timers.is_registered(_show_offer):
            bpy.app.timers.register(_show_offer, first_interval=1.0)


def offer_recover(on=True):
    """Offer a newer autosave when a file opens (``on=False`` removes it). One handler for every
    add-on: the first copy that registers keeps it."""
    ns = bpy.app.driver_namespace
    lst = bpy.app.handlers.load_post
    if on:
        owner = ns.get("liok_autosave_offer_owner")
        if owner is not None and owner in lst:
            return
        lst.append(_offer_on_load)
        ns["liok_autosave_offer_owner"] = _offer_on_load
    else:
        while _offer_on_load in lst:
            lst.remove(_offer_on_load)
        if ns.get("liok_autosave_offer_owner") is _offer_on_load:
            ns["liok_autosave_offer_owner"] = None
