# SPDX-License-Identifier: GPL-3.0-or-later
"""SSD Saver: Blender's autosave, written only after a change.

Blender's own autosave rewrites the whole .blend every interval as long as the file has unsaved
changes, even when nobody touched Blender for hours: a 2 GB file left open for a night with the
default timer is about 1.2 TB written to the disk, for a file that did not change. SSD Saver takes
over the autosave for the session: same file, same folder (Preferences > File Paths > Temporary
Files), same interval (Preferences > Save & Load > Auto Save > Timer), File > Recover > Auto Save
finds it as before. It writes only when something changed since the last autosave, at most one
interval after the first change, so the work lost after a crash is never more than the interval.
Nothing changed: nothing written. Disabling the add-on gives Blender its own autosave back.

The autosave itself is the Liok kit's ``liok_autosave`` (VR Builder and VR Animate use the same
one in VR: while a VR session runs, its own autosave writes and SSD Saver waits).
"""

import json
import os
import time

import bpy

from . import liok_autosave, liok_hub, liok_ui

ADDON_ID = "ssd_saver"
CHECK_EVERY = 5.0           # s between two looks at the clock (stats)
STATS_WRITE_EVERY = 600.0   # s between two writes of the small stats file


def _config_path():
    folder = bpy.utils.user_resource('CONFIG', path="ssd_saver", create=True)
    return os.path.join(folder, "ssd_saver.json")


def _read_config():
    try:
        with open(_config_path(), encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_config(data):
    try:
        with open(_config_path(), "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=1)
    except OSError as ex:
        print("SSD Saver: could not write its settings:", ex)


class Stats:
    """What SSD Saver wrote and what Blender's own autosave would have written meanwhile."""

    def __init__(self):
        self.written = 0            # autosaves written this session
        self.written_bytes = 0
        self.skipped = 0            # Blender would have rewritten the file, nothing had changed
        self.skipped_bytes = 0
        self.total_skipped_bytes = 0    # since the add-on was installed (the config file)
        self.last_write = None          # wall clock
        self._interval_start = time.monotonic()
        self._wrote_in_interval = False
        self._stats_written = time.monotonic()

    def file_size(self):
        """The size of one autosave of the open file: the last one written, else the file itself."""
        for path in (liok_autosave.recover_path(), bpy.data.filepath):
            try:
                if path and os.path.exists(path):
                    return os.path.getsize(path)
            except OSError:
                pass
        return 0

    def saved(self, path):
        self.written += 1
        try:
            self.written_bytes += os.path.getsize(path)
        except OSError:
            pass
        self.last_write = time.time()
        self._wrote_in_interval = True

    def tick(self):
        """Every Blender interval: had Blender's own autosave run, would it have written? (It
        writes while the file has unsaved changes.) If SSD Saver did not, that is one rewrite
        saved."""
        on, minutes = liok_autosave.settings()
        now = time.monotonic()
        if now - self._interval_start < minutes * 60.0:
            return
        self._interval_start = now
        if on and bpy.data.is_dirty and not self._wrote_in_interval:
            size = self.file_size()
            self.skipped += 1
            self.skipped_bytes += size
            self.total_skipped_bytes += size
        self._wrote_in_interval = False
        if now - self._stats_written > STATS_WRITE_EVERY:
            self.store()

    def store(self):
        self._stats_written = time.monotonic()
        data = _read_config()
        data["total_skipped_bytes"] = self.total_skipped_bytes
        _write_config(data)


stats = Stats()
keeper = liok_autosave.Keeper("SSD Saver", on_saved=stats.saved, background=True, compress=True)


def _wanted_on():
    """Autosave on or off, as the user wants it. Blender's own checkbox ticked: on (never taken
    over, or ticked again in the Preferences). Unticked: the choice SSD Saver remembered, or off
    the first time (the user had turned Blender's autosave off)."""
    fp = bpy.context.preferences.filepaths
    if fp.use_auto_save_temporary_files:
        return True
    return bool(_read_config().get("on", False))


def _set_on(on):
    data = _read_config()
    data["on"] = bool(on)
    _write_config(data)
    liok_autosave.take_over(on=on)


def _watch():
    """Blender's own checkbox ticked again in the Preferences: SSD Saver takes it over again
    (autosave on). Also counts what Blender would have written."""
    try:
        # Ticked by the user, not by SSD Saver itself (it turns Blender's own autosave on while a
        # change waits: kit liok_autosave 6).
        if (bpy.context.preferences.filepaths.use_auto_save_temporary_files
                and liok_autosave.state().get("native_armed") is None):
            _set_on(True)
            _sync_prop()
        stats.tick()
    except Exception as ex:
        print("SSD Saver:", ex)
    return CHECK_EVERY


def _sync_prop():
    _set_prop(liok_autosave.settings()[0])


_syncing = False


def _set_prop(on):
    """Show `on` in the Autosave checkbox without running its update callback. (Item assignment,
    prefs["autosave"] = on, is refused on add-on preferences in Blender 5.)"""
    global _syncing
    prefs = _prefs()
    if prefs is None or prefs.autosave == bool(on):
        return
    _syncing = True
    try:
        prefs.autosave = bool(on)
    finally:
        _syncing = False


def _prefs():
    addon = bpy.context.preferences.addons.get(__package__)
    return addon.preferences if addon is not None else None


def _human(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024.0


def draw_status(layout, context):
    on, minutes = liok_autosave.settings()
    fp = context.preferences.filepaths
    box = liok_ui.static_box(layout, "Autosave", icon='FILE_TICK')
    row = box.row(align=True)
    prefs = _prefs()
    if prefs is not None:
        row.prop(prefs, "autosave", text="Autosave")
    row.prop(fp, "auto_save_time", text="Every (min)")
    if not on:
        box.label(text="Off: nothing is autosaved", icon='ERROR')
        return
    box.label(text="Written only after a change", icon='CHECKMARK')
    d = liok_autosave.state()
    if d["foreground"]:
        box.label(text="A VR session autosaves meanwhile", icon='INFO')
    elif d["first_change"] is not None:
        left = max(0, int(minutes * 60 - (time.monotonic() - d["first_change"])))
        box.label(text=f"Changed: autosave in {left} s", icon='TIME')
    else:
        box.label(text="No change since the last save: nothing to write", icon='CHECKMARK')
    if stats.last_write is not None:
        box.label(text="Last autosave " + time.strftime("%H:%M", time.localtime(stats.last_write)))
    box = liok_ui.static_box(layout, "Disk writes avoided", icon='DISK_DRIVE')
    box.label(text=f"This session: {stats.skipped} rewrites, {_human(stats.skipped_bytes)}")
    box.label(text=f"Written: {stats.written} autosaves, {_human(stats.written_bytes)}")
    box.label(text=f"Since installed: {_human(stats.total_skipped_bytes)}")


class SSDSAVER_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    autosave: bpy.props.BoolProperty(
        name="Autosave", default=True,
        update=lambda self, ctx: None if _syncing else _set_on(self.autosave),
        description="Autosave the open file into Blender's temporary folder (File > Recover > Auto Save "
                    "finds it), only when something changed since the last autosave")

    def draw(self, context):
        draw_status(self.layout, context)
        col = self.layout.column()
        col.label(text="Blender's own Auto Save checkbox stays off while SSD Saver runs: SSD Saver "
                       "writes the same autosave file instead.", icon='INFO')
        col.label(text="Disabling SSD Saver gives Blender its own autosave back.")


class SSDSAVER_PT_main(bpy.types.Panel):
    bl_label = "SSD Saver"
    bl_idname = "SSDSAVER_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = liok_hub.CATEGORY
    bl_order = 95

    @classmethod
    def poll(cls, context):
        return liok_hub.is_active(ADDON_ID, context)

    def draw(self, context):
        draw_status(self.layout, context)


classes = (SSDSAVER_Preferences, SSDSAVER_PT_main)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    stats.total_skipped_bytes = int(_read_config().get("total_skipped_bytes", 0))
    on = _wanted_on()
    _set_on(on)
    _set_prop(on)
    liok_autosave.track_changes()
    liok_autosave.offer_recover()       # after a crash: the newer autosave offered when the file opens
    keeper.start()
    if not bpy.app.timers.is_registered(_watch):
        bpy.app.timers.register(_watch, first_interval=CHECK_EVERY, persistent=True)
    liok_hub.register_addon(ADDON_ID, "SSD Saver", __package__, icon='DISK_DRIVE', order=95)


def unregister():
    liok_hub.unregister_addon(ADDON_ID)
    if bpy.app.timers.is_registered(_watch):
        bpy.app.timers.unregister(_watch)
    keeper.stop()
    liok_autosave.untrack_changes()
    liok_autosave.offer_recover(on=False)
    liok_autosave.give_back()
    stats.store()
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
