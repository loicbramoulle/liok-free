# SPDX-License-Identifier: GPL-3.0-or-later
"""Panel building blocks shared by the Liok add-ons (see UI_GUIDELINES.md in the kit).

Meant for the Liok add-on kit (copied as is into each add-on, never edited by hand there).
Every function only draws with the layout it is given, so a panel stays cheap and nothing runs at rest.

    from . import liok_ui
    liok_ui.register() / unregister()                  # the toggle operator (refcounted)

    head, body = liok_ui.boxed_section(layout, scene, "myaddon_ui_export_open", "Export", icon='EXPORT')
    if body is not None:
        body.prop(...)                                 # body is already inside the dark box
    box = liok_ui.static_box(layout, "Gizmo", icon='GIZMO')    # titled group, no fold
    liok_ui.add_button(layout, "myaddon.add_thing", "Add Thing", 'ADD')   # left aligned
    liok_ui.tabs(layout, [("Base", 'TEXTURE'), ("Layer 1", 'NODETREE')], active, "myaddon.set_tab")
    # One section at a time (the whole panel as a tab grid, 3 per row, with an alert tab):
    active = liok_ui.section_tabs(layout, [("Project", 'FILE_FOLDER', not healthy), ("Sync", 'EXPORT')],
                                  active, "myaddon.set_tab")       # titles become "1 Project", "2 Sync"
    # Header row (no add-on name: the panel title is already above it): HOW TO + Tabs toggle.
    tabs_on = liok_ui.panel_header(layout, scene, "myaddon_ui_tabs", how_to="myaddon.how_to")  # or how_to_url="https://..."
    # Settings kept on a PropertyGroup (not an ID): the add-on's own operator flips the bool.
    tabs_on = liok_ui.panel_header(layout, settings, "ui_tabs", how_to_url=URL, tabs_operator="myaddon.toggle_tabs")
    liok_ui.key_table(layout, "Drag", 'MOUSE_LMB_DRAG', (("Click", "pick a part"), ("G", "Smart Grab", 'EVENT_G')))

The section state is a property of `owner` (a Scene, an Object...) that the add-on registers, or, when
there is none, a custom property stored on it. Headers are operator buttons, never boolean props:
click-dragging over boolean buttons is Blender's drag-toggle and flipped every checkbox the cursor crossed.
"""

KIT_FILE_VERSION = 6

OPERATOR = "liok_ui.toggle_open"
_REFS = "liok_ui_refs"
_RNA_NAME = "LIOK_UI_OT_toggle_open"


def is_open(owner, prop, default=False):
    """State of a section: the registered property if there is one, else a custom property."""
    if hasattr(owner, prop):
        return bool(getattr(owner, prop))
    try:
        return bool(owner.get(prop, default))
    except Exception:
        return default


def _set_open(owner, prop, value):
    if hasattr(owner, prop):
        setattr(owner, prop, value)
    else:
        owner[prop] = value


def boxed_section(layout, owner, prop, title, icon='NONE', default=False):
    """Foldable section in its own dark box: arrow, icon and title on one row, aligned left.

    `owner` must be an ID that an operator can find again by name (Scene, Object, Material, World...).
    Returns (header row, body column or None while closed). Put status widgets on the header row after
    the title, with `alignment = 'RIGHT'`.
    """
    box = layout.box()
    head = box.row(align=True)
    title_row = head.row(align=True)
    title_row.alignment = 'LEFT'
    opened = is_open(owner, prop, default)
    for text, shown in (("", 'TRIA_DOWN' if opened else 'TRIA_RIGHT'), (title, icon)):
        op = title_row.operator(OPERATOR, text=text, icon=shown, emboss=False)
        op.collection = _collection_of(owner)
        op.id_name = owner.name
        op.prop = prop
        op.default = default
    return head, (box.column(align=True) if opened else None)


def static_box(layout, title, icon='NONE'):
    """Titled group that never folds (icon + title, then the controls). Returns the column to draw into."""
    box = layout.box()
    box.label(text=title, icon=icon)
    return box.column(align=True)


def add_button(layout, operator, text, icon='ADD'):
    """Button that adds an object or a modifier: left aligned, so the eye reads 'Add ...' down one edge."""
    row = layout.row()
    row.alignment = 'LEFT'
    return row.operator(operator, text=text, icon=icon)


def tabs(layout, items, active, operator, index_prop="index", columns=2, numbered=False, first_index=0):
    """Row of tab buttons in a grid; the active one is pressed. `items` = [(title, icon[, alert]), ...].

    `operator` must have an int property `index_prop` and store the choice (with an INTERNAL option).
    `alert` (third value, optional) draws that tab in the alert colour, for example a Project tab while the
    setup is not valid. With `numbered`, the title is prefixed by the number (first_index + position).
    Returns the clamped active index (counted from first_index).
    """
    last = first_index + len(items) - 1
    active = max(first_index, min(int(active), last)) if items else first_index
    grid = layout.grid_flow(row_major=True, columns=columns, even_columns=True, even_rows=True, align=True)
    for position, item in enumerate(items):
        title, icon = item[0], item[1]
        index = first_index + position
        cell = grid.row(align=True)
        cell.alert = bool(item[2]) if len(item) > 2 else False
        text = "%d %s" % (index, title) if numbered else title
        op = cell.operator(operator, text=text, icon=icon, depress=(index == active))
        setattr(op, index_prop, index)
    return active


def section_tabs(layout, items, active, operator, index_prop="index", columns=3):
    """The whole panel as a grid of numbered tabs (1 Project, 2 Sync...), 3 per row: one section at a time.

    Same as `tabs`, numbered from 1. The add-on draws only the section of the returned tab, so the panel never
    scrolls. Keep titles to one short word (about 8 characters) so three fit a narrow panel, and give the
    add-on a "Tabs" toggle (Scene bool, on by default) that switches back to the list of boxed sections.
    """
    return tabs(layout, items, active, operator, index_prop=index_prop, columns=columns, numbered=True, first_index=1)


def panel_header(layout, owner, tabs_prop=None, how_to=None, how_to_url=None, default_tabs=True,
                 tabs_operator=None):
    """Top row of a Liok panel: [HOW TO] [Tabs]. Never the add-on name or icon, the panel title is right above.

    `how_to` is an operator id (popup, docs...), `how_to_url` opens a web page (online docs with pictures); give
    either or none. `tabs_prop` names a Scene (or `owner`) bool the add-on registers (the "Tabs" toggle is pressed
    while it is True, it flips through `liok_ui.toggle_open`, never a boolean button, so no drag-toggle). Returns
    True when the add-on should draw one section at a time with `section_tabs`, False for the list of boxed sections.
    `tabs_operator` (optional): an operator of the add-on that flips the bool itself, for an `owner` that
    `liok_ui.toggle_open` cannot find by name (a PropertyGroup on the window manager or the preferences).
    """
    tabs_on = bool(tabs_prop) and is_open(owner, tabs_prop, default_tabs)
    if not (how_to or how_to_url or tabs_prop):
        return tabs_on
    row = layout.row(align=True)
    if how_to:
        row.operator(how_to, text="HOW TO", icon='QUESTION')
    elif how_to_url:
        row.operator("wm.url_open", text="HOW TO", icon='QUESTION').url = how_to_url
    if tabs_prop and tabs_operator:
        row.operator(tabs_operator, text="Tabs", icon='NONE', depress=tabs_on)
    elif tabs_prop:
        op = row.operator(OPERATOR, text="Tabs", icon='NONE', depress=tabs_on)
        op.collection = _collection_of(owner)
        op.id_name = owner.name
        op.prop = tabs_prop
        op.default = default_tabs
    return tabs_on


def key_table(layout, title, icon, rows, factor=0.34):
    """Titled box of hotkey rows, the Smart Rig look: key right aligned, an arrow, then what it does.

    `rows` = (key, what) or (key, what, key_icon): the optional icon is a Blender key icon (`EVENT_G`,
    `MOUSE_LMB`...) drawn before the key text. The left part is `factor` of the width, so the arrows form one
    column and the descriptions start on one line. Keep `what` short (about 30 characters): a longer text is
    cut by the panel width.
    """
    col = static_box(layout, title, icon)
    for row in rows:
        key, what = row[0], row[1]
        key_icon = row[2] if len(row) > 2 else 'NONE'
        line = col.split(factor=factor, align=True)
        left = line.row()
        left.alignment = 'RIGHT'
        left.label(text=key, icon=key_icon)
        line.label(text=what, icon='FORWARD')
    return col


def _collection_of(owner):
    name = type(owner).__name__
    return {"Scene": "scenes", "Object": "objects", "Material": "materials", "World": "worlds",
            "Collection": "collections"}.get(name, "scenes")


try:
    import bpy

    class LIOK_UI_OT_toggle_open(bpy.types.Operator):
        bl_idname = OPERATOR
        bl_label = "Show / Hide"
        bl_description = "Open or close this section"
        bl_options = {'INTERNAL'}

        collection: bpy.props.StringProperty(options={'SKIP_SAVE'})
        id_name: bpy.props.StringProperty(options={'SKIP_SAVE'})
        prop: bpy.props.StringProperty(options={'SKIP_SAVE'})
        default: bpy.props.BoolProperty(options={'SKIP_SAVE'})

        def execute(self, context):
            owner = getattr(bpy.data, self.collection, {}).get(self.id_name)
            if owner is None or not self.prop:
                return {'CANCELLED'}
            _set_open(owner, self.prop, not is_open(owner, self.prop, self.default))
            for area in context.screen.areas if context.screen else ():
                area.tag_redraw()
            return {'FINISHED'}

    def register():
        """Refcounted: several add-ons can have this module, the operator exists once."""
        ns = bpy.app.driver_namespace
        ns[_REFS] = ns.get(_REFS, 0) + 1
        if ns[_REFS] == 1 and not hasattr(bpy.types, _RNA_NAME):
            bpy.utils.register_class(LIOK_UI_OT_toggle_open)

    def unregister():
        ns = bpy.app.driver_namespace
        ns[_REFS] = ns.get(_REFS, 1) - 1
        if ns[_REFS] <= 0:
            ns.pop(_REFS, None)
            # The live operator, whichever copy of this file registered it: the add-on enabled
            # second shares the first one's and its own class was never registered (unregistering
            # that raised "missing bl_rna attribute": VR Animate disabled with Smart Rig on).
            live = getattr(bpy.types, _RNA_NAME, None)
            for cls in (live, LIOK_UI_OT_toggle_open):
                if cls is not None and getattr(cls, "is_registered", False):
                    try:
                        bpy.utils.unregister_class(cls)
                    except RuntimeError:
                        pass
                    break
except ImportError:
    def register():
        pass

    def unregister():
        pass
