"""Updates of a collection add-on through Blender's extension system, without restarting.

Two channels, nothing to configure in the add-on:
- dev (liok): the add-on is installed from its private dev repository (a token kept in
  Blender's repository settings, never in the add-on). Updates come from there.
- public (users): the add-on was installed by dropping a release zip. If it is a FREE add-on
  (listed in liok_free.txt), the hub calls adopt(), which moves it to the public free
  repository (github.com/loicbramoulle/liok-free), which then provides the updates. No
  token: that repository is public and only ever holds FREE add-ons. Paid add-ons are never
  published there: they are updated through Superhive (Blender Extension Compatible) or by
  a new zip.
  Only release numbers (X.Y.Z) move: a dev build is never moved to the public channel.

Vendored in every add-on by the kit; liok_hub uses it for the Update buttons.
"""
import importlib
import json
import os
import re
import sys
import urllib.request

import bpy

# Free repository: the PUBLIC GitHub repository loicbramoulle/liok-free, holding the index.json
# and zips of the FREE add-ons only. Never publish a paid add-on there: anyone can read it.
# Empty: zip installs stay as they are.
COLLECTION_REPO_URL = os.environ.get(
    "LIOK_COLLECTION_REPO_URL",
    "https://raw.githubusercontent.com/loicbramoulle/liok-free/main/index.json")
COLLECTION_REPO_MODULE = "liok_free"
COLLECTION_REPO_NAME = "Liok Workshop (free)"


def _manifest(module_name):
    # sys.modules first: after a remove + reinstall, Blender may not set the add-on as an
    # attribute of its bl_ext.<repo> package, so walking attributes would fail.
    mod = sys.modules.get(module_name) or importlib.import_module(module_name)
    path = os.path.join(os.path.dirname(os.path.abspath(mod.__file__)), "blender_manifest.toml")
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    return {k: re.search(r'(?m)^%s = "(.*)"' % k, text).group(1) for k in ("id", "version")}


def _vtuple(v):
    # Every number counts, so a dev build like "1.7.0-alpha.5.2.132" is newer than
    # "1.7.0-alpha.5.2.131" (the first three numbers alone would call them equal).
    return tuple(int(x) for x in re.findall(r"\d+", v))


def newer(a, b):
    return _vtuple(a) > _vtuple(b)


def is_release(version):
    """True for a public release number (X.Y.Z). Dev builds carry more (X.Y.Z-alpha...)."""
    return re.fullmatch(r"\d+\.\d+\.\d+", version or "") is not None


def repo_of(module_name):
    """(index, repo) of the remote repository the add-on was installed from, else (None, None)."""
    parts = module_name.split(".")
    if len(parts) < 3 or parts[0] != "bl_ext":
        return None, None
    for i, r in enumerate(bpy.context.preferences.extensions.repos):
        if r.module == parts[1] and r.enabled and r.use_remote_url and r.remote_url:
            return i, r
    return None, None


def info(module_name):
    """Main thread: what the update check needs (no network)."""
    m = _manifest(module_name)
    _, repo = repo_of(module_name)
    if not bpy.app.online_access:  # Blender's "Allow Online Access" is off: never go online
        repo = None
    token = repo.access_token if repo is not None and repo.use_access_token else None
    return {"pkg_id": m["id"], "installed": m["version"],
            "repo_url": repo.remote_url if repo is not None else None, "token": token}


def latest_version(url, token, pkg_id, timeout=10):
    """Any thread: version of pkg_id in a repository index."""
    if not url.endswith(".json"):
        url = url.rstrip("/") + "/index.json"
    req = urllib.request.Request(url)
    if token:
        req.add_header("Authorization", "Bearer " + token)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        index = json.loads(resp.read().decode("utf-8"))
    for pkg in index.get("data", []):
        if pkg.get("id") == pkg_id:
            return pkg["version"]
    return None


def _run(op, **kw):
    wm = bpy.context.window_manager
    win = wm.windows[0] if wm and wm.windows else None
    if win is None:
        return op(**kw)
    with bpy.context.temp_override(window=win):
        return op(**kw)


def install_update(module_name):
    """Main thread: sync the add-on's repository and install its latest version in place.
    Call it from a timer, never from an operator of the add-on being reinstalled."""
    idx, repo = repo_of(module_name)
    if repo is None:
        raise RuntimeError("installed without an update repository")
    _run(bpy.ops.extensions.repo_sync, repo_index=idx)
    _run(bpy.ops.extensions.package_install, repo_index=idx, pkg_id=_manifest(module_name)["id"],
         enable_on_install=True)


def adoptable(module_name):
    """Main thread, no network: pkg id when this install could join the collection repository
    (a zip install of a public release, online access allowed), else None. Dev builds
    (X.Y.Z-alpha..., installed by a script or a dropped dev zip) are never moved."""
    parts = module_name.split(".")
    if not COLLECTION_REPO_URL or len(parts) < 3 or parts[0] != "bl_ext":
        return None
    if repo_of(module_name)[1] is not None or not bpy.app.online_access:
        return None
    m = _manifest(module_name)
    return m["id"] if is_release(m["version"]) else None


def adopt(module_name, published=False):
    """Main thread: move a zip install to the public collection repository. True when done.
    published=True: the caller already saw the add-on in the collection index (no network here)."""
    import addon_utils
    parts = module_name.split(".")
    pkg_id = adoptable(module_name)
    if pkg_id is None:
        return False
    if not published:
        try:
            if not latest_version(COLLECTION_REPO_URL, None, pkg_id):
                return False
        except OSError:
            return False  # collection repository not reachable: keep the zip install
    repos = bpy.context.preferences.extensions.repos
    old_idx = next(i for i, r in enumerate(repos) if r.module == parts[1])
    found = [(i, r) for i, r in enumerate(repos) if r.use_remote_url and r.remote_url == COLLECTION_REPO_URL]
    if found:
        idx, repo = found[0]
    else:
        repo = repos.new(name=COLLECTION_REPO_NAME, module=COLLECTION_REPO_MODULE, remote_url=COLLECTION_REPO_URL)
        idx = list(repos).index(repo)
    _run(bpy.ops.extensions.repo_sync, repo_index=idx)
    _run(bpy.ops.extensions.package_install, repo_index=idx, pkg_id=pkg_id, enable_on_install=False)
    addon_utils.disable(module_name, default_set=True)
    _run(bpy.ops.extensions.package_uninstall, repo_index=old_idx, pkg_id=pkg_id)
    addon_utils.enable("bl_ext.%s.%s" % (repo.module, pkg_id), default_set=True)
    return True


def auto_update(module_name):
    """Main thread, for an add-on that wants updates without a click. Returns True when the
    add-on was reinstalled (its module is reloaded: stop any timer of the old module)."""
    if adopt(module_name):
        return True
    i = info(module_name)
    if not i["repo_url"]:
        return False
    latest = latest_version(i["repo_url"], i["token"], i["pkg_id"])
    if latest and newer(latest, i["installed"]):
        install_update(module_name)
        return True
    return False
