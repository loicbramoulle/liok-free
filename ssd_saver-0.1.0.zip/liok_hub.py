"""Liok collection hub: one N-panel tab shared by all of liok's add-ons.

Every add-on of the collection vendors this file (copied by the kit) and calls
register_addon() / unregister_addon(). Whatever add-ons are installed, Blender shows one
tab with, at the top: the collection brand, links to the stores, the available updates,
and one button per installed add-on to switch between them. The newest HUB_VERSION among
the installed copies draws the hub, so updating one add-on updates the hub for all.

In an add-on:
    from . import liok_hub, liok_updates
    liok_hub.register_addon("SITCOM", "Sitcom", __package__, icon='SEQUENCE', order=30)
    ...
    class MYADDON_PT_main(bpy.types.Panel):
        bl_category = liok_hub.CATEGORY
        @classmethod
        def poll(cls, context):
            return liok_hub.is_active("SITCOM", context)

An add-on that must not be reinstalled at some moments (a paint session running...) passes
can_update=fn to register_addon(): fn() returns True, or (False, "reason"). While it says no,
the Update click waits (the panel shows the reason) and installs as soon as it says yes.

More from Liok Workshop (hub 12): a folded section lists the add-ons of the collection that are not
installed, read from catalog.json next to the free repository's index.json (public, free and
paid entries). Free ones have Install / Install All Free (from the free repository); paid ones
have Get (their store page). Nothing goes online until the section is opened, nor when Blender's
Allow Online Access is off.

Reload (hub 9): files of an add-on replaced on disk behind Blender's back (an install script, a
copy, a git pull) are noticed by the hub, which shows "new files on disk" with a Reload button;
a small reload icon on the version line does the same on demand. Reload disables the add-on,
drops its modules and enables it again (preferences kept), like Blender's own Update does. It
respects can_update. An add-on that must reload several packages in a given order passes
reload=fn to register_addon(): the hub then calls fn() instead of the generic reload.
"""
import importlib
import json
import os
import sys
import threading
import time
import types
import urllib.request

import bpy

HUB_VERSION = 12

# ---- Collection branding (change here, bump HUB_VERSION, release any add-on) ----------
BRAND = "Liok Workshop"
CATEGORY = "Liok"
LINKS = (  # (label, url, icon): empty urls are hidden. Labels are shown on the buttons.
    ("Superhive", "https://superhivemarket.com/creators/liok", 'FUND'),
    ("Gumroad", "https://liok.gumroad.com/", 'WORLD'),
    ("Site", "", 'WORLD'),
)
ACTIVE_KEY = "liok_active_tab"  # scene property, same key as the BURAMU / Smartify tabs
CHECK_DELAY_S = 15.0
CHECK_EVERY_S = 10 * 60.0
DEFER_RETRY_S = 5.0  # an update an add-on refused (can_update) is tried again this often
RELOAD_CHECK_S = 10.0  # how often the files of every add-on are compared with what is loaded
_STAMP_SKIP_DIRS = {"__pycache__", "textures", "_godot_addon", "libraries", "tests"}


def _state():
    """Shared between the vendored copies of every add-on, for the whole Blender session."""
    st = sys.modules.get("_liok_hub_state")
    if st is None:
        st = types.ModuleType("_liok_hub_state")
        st.addons = {}        # addon_id -> dict(label, module, icon, order, can_update)
        st.updates = {}       # addon_id -> (installed, latest)
        st.hub_version = 0
        st.classes = ()
        st.lock = threading.Lock()
        sys.modules["_liok_hub_state"] = st
    # An older hub copy may have created the state with fewer fields.
    for name, default in (("addons", dict), ("updates", dict), ("classes", tuple), ("deferred", dict),
                          ("disabled", dict)):
        if not hasattr(st, name):
            setattr(st, name, default())
    if not hasattr(st, "hub_version"):
        st.hub_version = 0
    if not hasattr(st, "lock"):
        st.lock = threading.Lock()
    if not hasattr(st, "reload_ids"):
        st.reload_ids, st.reload_checked = [], 0.0
    if not hasattr(st, "status"):
        st.status = {}  # addon_id -> (installed, latest or None, "ok" | "local" | "error")
    if not hasattr(st, "catalog"):
        st.catalog, st.catalog_state, st.catalog_error = [], "idle", ""  # idle | loading | ok | error
    return st


def addons_sorted():
    """Tab order: the add-on's own `order`, then its label, then its id: the same whatever the
    order the add-ons were turned on in (registration order never counts)."""
    return sorted(_state().addons.items(), key=lambda kv: (kv[1]["order"], kv[1]["label"].lower(), kv[0]))


def active_id(context):
    items = addons_sorted()
    if not items:
        return None
    ids = [k for k, _ in items]
    current = str(context.scene.get(ACTIVE_KEY, "")) if context.scene else ""
    return current if current in ids else ids[0]


def is_active(addon_id, context):
    """Poll helper for an add-on's panels: shown only when its button is selected."""
    return active_id(context) == addon_id


def _redraw():
    for win in getattr(bpy.context.window_manager, "windows", []):
        for area in win.screen.areas:
            if area.type in {'VIEW_3D', 'SEQUENCE_EDITOR', 'NODE_EDITOR'}:
                area.tag_redraw()


# ---- updates ---------------------------------------------------------------------------

def _updater(entry):
    try:
        return importlib.import_module(entry["module"] + ".liok_updates")
    except ImportError:
        return None


def _check_all():
    """Read installed versions on the main thread, fetch remote indexes in a thread.
    A zip install of a public release found in the collection repository is moved there
    (adopt) so it gets its updates from then on."""
    st = _state()
    jobs, adopt_jobs = [], []
    for addon_id, entry in list(st.addons.items()):
        up = _updater(entry)
        if up is None:
            continue
        try:
            info = up.info(entry["module"])
        except Exception:
            info = None
        if info and info.get("repo_url"):
            jobs.append((addon_id, up, info))
        elif info:
            with st.lock:
                st.status[addon_id] = (info["installed"], None, "local")
        try:
            pkg_id = up.adoptable(entry["module"]) if hasattr(up, "adoptable") else None
        except Exception:
            pkg_id = None
        if pkg_id:
            adopt_jobs.append((entry["module"], up, pkg_id))

    def work():
        found = {}
        status = {}
        for addon_id, up, info in jobs:
            try:
                latest = up.latest_version(info["repo_url"], info.get("token"), info["pkg_id"])
            except Exception:
                status[addon_id] = (info["installed"], None, "error")
                continue
            status[addon_id] = (info["installed"], latest, "ok")
            if latest and up.newer(latest, info["installed"]):
                found[addon_id] = (info["installed"], latest)
        to_adopt = []
        for module, up, pkg_id in adopt_jobs:
            try:
                if up.latest_version(up.COLLECTION_REPO_URL, None, pkg_id):
                    to_adopt.append((module, up))
            except Exception:
                continue
        with st.lock:
            st.updates = found
            st.status.update(status)
        bpy.app.timers.register(lambda: (_redraw(), None)[1], first_interval=0.1)
        if to_adopt:
            bpy.app.timers.register(lambda: _adopt_now(to_adopt), first_interval=0.2)

    threading.Thread(target=work, daemon=True).start()


def _adopt_now(items):
    for module, up in items:
        try:
            up.adopt(module, published=True)
        except Exception as e:
            print("Liok hub: could not move %s to the collection repository: %s" % (module, e))
    return None


def _blocked(entry):
    """Reason the add-on refuses to be reinstalled now (its can_update hook), else None."""
    fn = entry.get("can_update")
    if fn is None:
        return None
    try:
        res = fn()
    except Exception as e:
        print("Liok hub: can_update of %s failed, updating anyway: %s" % (entry["label"], e))
        return None
    ok, reason = res if isinstance(res, tuple) else (res, "")
    return None if ok else (reason or "busy")


def _install_now(entries):
    """Timer body: reinstalling an add-on unloads its operators, so never do it from one.
    Add-ons whose can_update says no stay in `entries` and the timer tries again."""
    st = _state()
    done, waiting = [], []
    for addon_id, entry in entries:
        entry = st.addons.get(addon_id)  # None: unregistered while its update was waiting
        up = _updater(entry) if entry else None
        if up is None:
            st.deferred.pop(addon_id, None)
            continue
        reason = _blocked(entry)
        if reason:
            st.deferred[addon_id] = reason
            waiting.append((addon_id, entry))
            continue
        st.deferred.pop(addon_id, None)
        try:
            up.install_update(entry["module"])
            done.append(entry["label"])
            with st.lock:
                st.updates.pop(addon_id, None)
                st.status.pop(addon_id, None)
        except Exception as e:
            st.update_error = "%s: %s" % (entry["label"], e)
            print("Liok hub: update failed:", st.update_error)
    if done:
        print("Liok hub: updated " + ", ".join(done))
        st.status_requested = False  # the version line re-reads the new versions
    _redraw()
    entries[:] = waiting
    return DEFER_RETRY_S if waiting else None


def _tick():
    st = _state()
    if not st.addons:
        st.timer = None
        return None
    _check_all()
    return CHECK_EVERY_S


# ---- Liok add-ons installed but turned off in Preferences -----------------------------------
# Never periodic: the scan runs at the first draw, on the refresh arrow, and when an add-on
# turns on or off. Drawing only reads what the last scan found.

def _scan_disabled():
    """Main thread: {module: label} of the installed Liok add-ons (a liok_hub.py next to their
    __init__.py) that are off, and warn once about panels that would shake the hub's position."""
    import addon_utils
    st = _state()
    enabled = set(bpy.context.preferences.addons.keys())
    on_ids = {name.rsplit(".", 1)[-1] for name in enabled}
    on_ids.update(e["module"].rsplit(".", 1)[-1] for e in st.addons.values())
    found = {}
    for mod in addon_utils.modules(refresh=False):
        name = getattr(mod, "__name__", "")
        path = getattr(mod, "__file__", None)
        # An old copy of an add-on that is on under another module name (zip next to the
        # extension) is not "turned off": it is the same add-on.
        if not path or name in enabled or name.rsplit(".", 1)[-1] in on_ids:
            continue
        if not os.path.isfile(os.path.join(os.path.dirname(path), "liok_hub.py")):
            continue
        info = getattr(mod, "bl_info", None) or {}
        found[name] = str(info.get("name") or name.rsplit(".", 1)[-1])
    if not getattr(st, "order_checked", False):
        st.order_checked = True
        for cls in bpy.types.Panel.__subclasses__():
            if (getattr(cls, "bl_category", "") == CATEGORY and getattr(cls, "bl_space_type", "") == 'VIEW_3D'
                    and not getattr(cls, "bl_parent_id", "") and cls.__name__ != "LIOK_PT_hub"
                    and getattr(cls, "bl_order", 0) <= 0):
                print("Liok hub: panel %s has bl_order %s: use 1 or more, the hub panel is 0 and "
                      "keeps the first place only that way" % (cls.__name__, getattr(cls, "bl_order", 0)))
    return found


def scan_now():
    """Scan now (main thread) and remember the result. Returns it."""
    st = _state()
    st.disabled = _scan_disabled()
    return st.disabled


def _request_scan(delay=0.3):
    st = _state()
    if getattr(st, "scan_pending", False):
        return
    st.scan_pending = True

    def run():
        st.scan_pending = False
        try:
            scan_now()
        except Exception as e:
            print("Liok hub: could not list the add-ons turned off:", e)
        _redraw()
        return None
    bpy.app.timers.register(run, first_interval=delay)


def _enable_now(modules):
    """Timer body (an add-on turning on may replace the hub's own classes, never do it from
    an operator or a draw): turn the add-ons on like the Preferences checkbox does."""
    import addon_utils
    st = _state()
    failed = []
    for name in modules:
        errors = []
        try:
            mod = addon_utils.enable(name, default_set=True, handle_error=errors.append)
        except Exception as e:
            mod, errors = None, [e]
        if mod is None:
            failed.append("%s (%s)" % (st.disabled.get(name, name), errors[0] if errors else "see the console"))
    st.enable_error = "; ".join(failed)
    try:
        scan_now()
    except Exception as e:
        print("Liok hub: could not list the add-ons turned off:", e)
    _redraw()
    return None


# ---- reload ----------------------------------------------------------------------------

def _disk_stamp(module):
    """Cheap fingerprint of an add-on's code on disk (count, bytes, newest mtime of its .py
    files and manifest). None when the package location is unknown."""
    mod = sys.modules.get(module)
    path = getattr(mod, "__file__", None)
    if not path:
        return None
    count = size = newest = 0
    for folder, dirs, files in os.walk(os.path.dirname(path)):
        dirs[:] = [d for d in dirs if d not in _STAMP_SKIP_DIRS and not d.startswith(".")]
        for name in files:
            if name.endswith(".py") or name == "blender_manifest.toml":
                try:
                    info = os.stat(os.path.join(folder, name))
                except OSError:
                    continue
                count += 1
                size += info.st_size
                newest = max(newest, info.st_mtime_ns)
    return (count, size, newest)


def reload_pending(force=False):
    """Add-on ids whose files on disk differ from the code Blender loaded."""
    st = _state()
    now = time.monotonic()
    if force or now - st.reload_checked >= RELOAD_CHECK_S:
        st.reload_checked = now
        ids = []
        for addon_id, entry in st.addons.items():
            loaded = entry.get("loaded_stamp")
            if loaded is None:
                continue  # registered by an older hub copy: nothing to compare with
            try:
                disk = _disk_stamp(entry["module"])
            except Exception:
                disk = None
            if disk is not None and disk != loaded:
                ids.append(addon_id)
        st.reload_ids = ids
    return [i for i in st.reload_ids if i in st.addons]


def _generic_reload(modules):
    import addon_utils
    for module in reversed(modules):
        addon_utils.disable(module, default_set=False)
    for module in modules:
        prefix = module + "."
        for key in list(sys.modules):
            if key == module or key.startswith(prefix):
                sys.modules.pop(key, None)
        parent, _sep, child = module.rpartition(".")
        if parent and hasattr(sys.modules.get(parent), child):
            delattr(sys.modules[parent], child)
    importlib.invalidate_caches()
    for module in modules:
        addon_utils.enable(module, default_set=False)


def _reload_now(entries):
    """Timer body: a reload unregisters the operators, so never run it from one.
    Add-ons whose can_update says no stay in `entries` and the timer tries again."""
    st = _state()
    waiting, generic, custom = [], [], []
    for addon_id, _entry in entries:
        entry = st.addons.get(addon_id)
        if entry is None:
            st.deferred.pop(addon_id, None)
            continue
        reason = _blocked(entry)
        if reason:
            st.deferred[addon_id] = reason
            waiting.append((addon_id, entry))
            continue
        st.deferred.pop(addon_id, None)
        (custom if entry.get("reload") else generic).append((addon_id, entry))
    generic.sort(key=lambda kv: kv[1]["order"])
    done = []
    try:
        if generic:
            _generic_reload([e["module"] for _, e in generic])
            done += [e["label"] for _, e in generic]
        for addon_id, entry in custom:
            # A hook may reload several add-ons at once: an entry registered anew meanwhile
            # was reloaded already.
            if st.addons.get(addon_id) is not entry:
                continue
            entry["reload"]()
            done.append(entry["label"])
        st.reload_error = ""
    except Exception as e:
        st.reload_error = str(e)
        print("Liok hub: reload failed:", e)
    if done:
        print("Liok hub: reloaded " + ", ".join(done))
        st.status_requested = False
    reload_pending(force=True)
    _redraw()
    entries[:] = waiting
    return DEFER_RETRY_S if waiting else None


# ---- UI --------------------------------------------------------------------------------

class LIOK_OT_hub_tab(bpy.types.Operator):
    """Show this add-on of the collection"""
    bl_idname = "liok.hub_tab"
    bl_label = "Add-on"
    bl_options = {'INTERNAL'}
    target: bpy.props.StringProperty()

    def execute(self, context):
        context.scene[ACTIVE_KEY] = self.target
        _redraw()
        return {'FINISHED'}


class LIOK_OT_hub_update(bpy.types.Operator):
    """Install the new version (no Blender restart)"""
    bl_idname = "liok.hub_update"
    bl_label = "Update"
    target: bpy.props.StringProperty(description="Add-on id, empty for all")

    def execute(self, context):
        st = _state()
        targets = [self.target] if self.target else list(st.updates)
        entries = [(t, st.addons[t]) for t in targets if t in st.addons and t not in st.deferred]
        st.update_error = ""
        if entries:
            bpy.app.timers.register(lambda: _install_now(entries), first_interval=0.05)
        return {'FINISHED'}


class LIOK_OT_hub_enable(bpy.types.Operator):
    """Turn this Liok add-on on again (the same as its checkbox in Preferences)"""
    bl_idname = "liok.hub_enable"
    bl_label = "Enable"
    bl_options = {'INTERNAL'}
    target: bpy.props.StringProperty(description="Module name, empty for all")

    def execute(self, context):
        st = _state()
        targets = [self.target] if self.target else list(st.disabled)
        st.enable_error = ""
        if targets:
            bpy.app.timers.register(lambda: _enable_now(targets), first_interval=0.05)
        return {'FINISHED'}


class LIOK_OT_hub_reload(bpy.types.Operator):
    """Load the files installed on disk without restarting Blender (preferences kept)"""
    bl_idname = "liok.hub_reload"
    bl_label = "Reload"
    target: bpy.props.StringProperty(description="Add-on id, empty for every add-on with new files")

    def execute(self, context):
        st = _state()
        targets = [self.target] if self.target else reload_pending(force=True)
        entries = [(t, st.addons[t]) for t in targets if t in st.addons and t not in st.deferred]
        st.reload_error = ""
        if entries:
            bpy.app.timers.register(lambda: _reload_now(entries), first_interval=0.05)
        return {'FINISHED'}


def _short(text, limit=60):
    """One short line of an error: the panel cannot show more, the full text is one click away."""
    text = " ".join(str(text).split())
    return text if len(text) <= limit else text[:limit - 1] + "..."


class LIOK_OT_hub_copy_error(bpy.types.Operator):
    """Copy the full error text to the clipboard"""
    bl_idname = "liok.hub_copy_error"
    bl_label = "Copy full error"
    bl_options = {'INTERNAL'}
    which: bpy.props.StringProperty(default="update")

    @classmethod
    def description(cls, context, properties):
        text = str(getattr(_state(), properties.which + "_error", "")).strip()
        return text[:800] + ("..." if len(text) > 800 else "") if text else cls.__doc__

    def execute(self, context):
        text = str(getattr(_state(), self.which + "_error", ""))
        context.window_manager.clipboard = text
        self.report({'INFO'}, "Error copied (%d characters)" % len(text))
        return {'FINISHED'}


class LIOK_OT_hub_check(bpy.types.Operator):
    """Check for new versions of the collection"""
    bl_idname = "liok.hub_check"
    bl_label = "Check for Updates"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        _check_all()
        _request_scan(0.1)
        return {'FINISHED'}


class LIOK_PT_hub(bpy.types.Panel):
    bl_label = BRAND
    bl_idname = "LIOK_PT_hub"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = CATEGORY
    bl_order = 0

    def draw_header(self, context):
        self.layout.label(text="", icon='PACKAGE')

    def draw(self, context):
        st = _state()
        layout = self.layout
        # The header already says BRAND: this line is the store links, readable as words.
        # The update check lives on the version line below.
        row = layout.row(align=True)
        for label, url, icon in LINKS:
            if url:
                op = row.operator("wm.url_open", text=label, icon=icon)
                op.url = url

        with st.lock:
            updates = dict(st.updates)
        if updates:
            box = layout.box()
            box.alert = True
            for addon_id, (old, new) in updates.items():
                entry = st.addons.get(addon_id)
                if entry is None:
                    continue
                r = box.row(align=True)
                waiting = st.deferred.get(addon_id)
                if waiting:
                    r.label(text="%s %s → %s, waiting: %s" % (entry["label"], old, new, waiting), icon='TIME')
                    continue
                r.label(text="%s %s → %s" % (entry["label"], old, new), icon='IMPORT')
                r.operator("liok.hub_update", text="", icon='CHECKMARK').target = addon_id
            if len(updates) > 1:
                box.operator("liok.hub_update", text="Update All", icon='IMPORT').target = ""
        error = getattr(st, "update_error", "")
        if error:
            r = layout.row(align=True)
            r.alert = True
            r.label(text="Update failed: " + _short(error), icon='ERROR')
            r.operator("liok.hub_copy_error", text="", icon='COPYDOWN').which = "update"

        pending = reload_pending()
        if pending:
            box = layout.box()
            box.alert = True
            for addon_id in pending:
                r = box.row(align=True)
                waiting = st.deferred.get(addon_id)
                if waiting:
                    r.label(text="%s: new files, waiting: %s" % (st.addons[addon_id]["label"], waiting), icon='TIME')
                    continue
                r.label(text="%s: new files on disk" % st.addons[addon_id]["label"], icon='FILE_REFRESH')
                r.operator("liok.hub_reload", text="Reload").target = addon_id
            if len(pending) > 1:
                box.operator("liok.hub_reload", text="Reload All", icon='FILE_REFRESH').target = ""
        error = getattr(st, "reload_error", "")
        if error:
            r = layout.row(align=True)
            r.alert = True
            r.label(text="Reload failed: " + _short(error), icon='ERROR')
            r.operator("liok.hub_copy_error", text="", icon='COPYDOWN').which = "reload"

        items = addons_sorted()
        if len(items) > 1:
            active = active_id(context)
            n = len(items)
            columns = n if n <= 3 else (2 if n == 4 else 3)
            grid = layout.grid_flow(row_major=True, columns=columns, even_columns=True, align=True)
            grid.scale_y = 1.4
            for addon_id, entry in items:
                op = grid.operator("liok.hub_tab", text=entry["label"], icon=entry["icon"],
                                   depress=(addon_id == active))
                op.target = addon_id
        _draw_version(layout, st, context)
        _draw_disabled(layout, st)


# ---- More from Liok Workshop: the add-ons of the collection that are not installed yet ---------

def _any_updater():
    for entry in _state().addons.values():
        up = _updater(entry)
        if up is not None and getattr(up, "COLLECTION_REPO_URL", ""):
            return up
    return None


def _parse_catalog(data):
    """Valid items of a catalog.json: [{id, name, tagline, free, url, icon}]. Anything odd is dropped."""
    items = []
    raw = data.get("items", []) if isinstance(data, dict) else []
    for it in raw if isinstance(raw, list) else []:
        if not isinstance(it, dict) or not isinstance(it.get("id"), str) or not isinstance(it.get("name"), str):
            continue
        url = it.get("url") if isinstance(it.get("url"), str) else ""
        if url and not url.startswith(("https://", "http://")):
            url = ""
        free = it.get("free") is True
        if not free and not url:
            continue  # a paid add-on without a store page cannot be offered
        icon = it.get("icon") if isinstance(it.get("icon"), str) else "PACKAGE"
        items.append({"id": it["id"], "name": it["name"], "free": free, "url": url, "icon": icon,
                      "tagline": it.get("tagline") if isinstance(it.get("tagline"), str) else ""})
    return items


def _load_catalog():
    """Main thread: start reading catalog.json (a thread). Called when the section is open."""
    st = _state()
    up = _any_updater()
    if up is None:
        st.catalog_state, st.catalog_error = "error", "no add-on with an update channel"
        return
    url = up.COLLECTION_REPO_URL.rsplit("/", 1)[0] + "/catalog.json"
    st.catalog_state = "loading"

    def work():
        try:
            with urllib.request.urlopen(urllib.request.Request(url), timeout=10) as resp:
                items = _parse_catalog(json.loads(resp.read().decode("utf-8")))
            result = ("ok", items, "")
        except Exception as e:
            result = ("error", [], str(e))
        with st.lock:
            st.catalog_state, st.catalog, st.catalog_error = result
        bpy.app.timers.register(lambda: (_redraw(), None)[1], first_interval=0.1)

    threading.Thread(target=work, daemon=True).start()


def _installed_ids():
    st = _state()
    ids = {e["module"].rsplit(".", 1)[-1] for e in st.addons.values()}
    ids.update(name.rsplit(".", 1)[-1] for name in st.disabled)
    return ids


def _more_items():
    """Catalog items not installed (nor turned off in Preferences)."""
    st = _state()
    have = _installed_ids()
    with st.lock:
        return [it for it in st.catalog if it["id"] not in have]


def _more_install_now(pkg_ids):
    """Timer body: add the free repository if needed, then install and enable the packages."""
    st = _state()
    up = _any_updater()
    try:
        if up is None:
            raise RuntimeError("no update channel")
        if not bpy.app.online_access:
            raise RuntimeError("allow online access in Blender's preferences (System)")
        url = up.COLLECTION_REPO_URL
        repos = bpy.context.preferences.extensions.repos
        found = [(i, r) for i, r in enumerate(repos) if r.use_remote_url and r.remote_url == url]
        if found:
            idx = found[0][0]
        else:
            repo = repos.new(name=up.COLLECTION_REPO_NAME, module=up.COLLECTION_REPO_MODULE, remote_url=url)
            idx = list(repos).index(repo)
        up._run(bpy.ops.extensions.repo_sync, repo_index=idx)
        for pkg_id in pkg_ids:
            up._run(bpy.ops.extensions.package_install, repo_index=idx, pkg_id=pkg_id, enable_on_install=True)
        st.more_error = ""
    except Exception as e:
        st.more_error = str(e)
        print("Liok hub: install failed:", e)
    _request_scan(0.5)
    _redraw()
    return None


class LIOK_OT_hub_more_install(bpy.types.Operator):
    """Install this free add-on of the Liok collection (all of them when empty)"""
    bl_idname = "liok.hub_more_install"
    bl_label = "Install"
    target: bpy.props.StringProperty(options={'SKIP_SAVE'})

    def execute(self, context):
        free = [it["id"] for it in _more_items() if it["free"]]
        ids = [self.target] if self.target else free
        ids = [i for i in ids if i in free]
        if ids:
            # A timer: installing from the click would unload operators while they run.
            bpy.app.timers.register(lambda: _more_install_now(ids), first_interval=0.05)
        return {'FINISHED'}


class LIOK_OT_hub_more_refresh(bpy.types.Operator):
    """Read the list of Liok add-ons again"""
    bl_idname = "liok.hub_more_refresh"
    bl_label = "Refresh"

    def execute(self, context):
        _state().catalog_state = "idle"
        _redraw()
        return {'FINISHED'}


class LIOK_PT_hub_more(bpy.types.Panel):
    bl_label = "More from " + BRAND
    bl_idname = "LIOK_PT_hub_more"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = CATEGORY
    bl_parent_id = "LIOK_PT_hub"
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        self.layout.label(text="", icon='ADD')

    def draw(self, context):
        # Drawn only while the section is open: that is the only moment anything goes online.
        st = _state()
        layout = self.layout
        if not bpy.app.online_access:
            layout.label(text="Allow Online Access (Preferences > System)", icon='INFO')
            layout.label(text="to see the other Liok add-ons.")
            return
        if st.catalog_state == "idle":
            _load_catalog()
        if st.catalog_state == "loading":
            layout.label(text="Loading...", icon='TIME')
            return
        if st.catalog_state == "error":
            r = layout.row()
            r.alert = True
            r.label(text="Could not load the list: " + _short(st.catalog_error), icon='ERROR')
            layout.operator("liok.hub_more_refresh", text="Retry", icon='FILE_REFRESH')
            return
        items = _more_items()
        error = getattr(st, "more_error", "")
        if error:
            r = layout.row()
            r.alert = True
            r.label(text="Install failed: " + _short(error), icon='ERROR')
        if not items:
            layout.label(text="You have every Liok add-on.", icon='CHECKMARK')
        for it in items:
            box = layout.box()
            row = box.row(align=True)
            row.label(text=it["name"], icon=it["icon"])
            if it["free"]:
                row.operator("liok.hub_more_install", text="Install", icon='IMPORT').target = it["id"]
            else:
                row.operator("wm.url_open", text="Get", icon='URL').url = it["url"]
            if it["tagline"]:
                col = box.column(align=True)
                col.scale_y = 0.8
                col.label(text=_short(it["tagline"], 70))
        if sum(1 for it in items if it["free"]) > 1:
            layout.operator("liok.hub_more_install", text="Install All Free", icon='IMPORT').target = ""
        layout.operator("liok.hub_more_refresh", text="", icon='FILE_REFRESH', emboss=False)


def _draw_disabled(layout, st):
    """Last block of the hub, so nothing above it ever moves: the Liok add-ons that are off."""
    if not getattr(st, "scanned", False):
        st.scanned = True
        _request_scan(0.1)
    error = getattr(st, "enable_error", "")
    if error:
        r = layout.row()
        r.alert = True
        r.label(text="Could not turn on: " + _short(error), icon='ERROR')
    if not st.disabled:
        return
    box = layout.box()
    box.alert = True
    box.label(text="Turned off in Preferences", icon='INFO')
    for name, label in sorted(st.disabled.items(), key=lambda kv: (kv[1].lower(), kv[0])):
        box.operator("liok.hub_enable", text=label, icon='CHECKBOX_DEHLT').target = name
    if len(st.disabled) > 1:
        box.operator("liok.hub_enable", text="Enable All", icon='CHECKBOX_HLT').target = ""


def _draw_version(layout, st, context):
    """Always visible: version of the selected add-on and whether it is up to date."""
    addon_id = active_id(context)
    entry = st.addons.get(addon_id) if addon_id else None
    if entry is None:
        return
    with st.lock:
        status = st.status.get(addon_id)
        update = st.updates.get(addon_id)
    row = layout.row(align=True)
    if update:
        row.alert = True
        row.label(text="%s %s → %s" % (entry["label"], update[0], update[1]), icon='ERROR')
        waiting = st.deferred.get(addon_id)
        if waiting:
            layout.label(text="Update waiting: " + waiting, icon='TIME')
        else:
            row.operator("liok.hub_update", text="Update", icon='IMPORT').target = addon_id
        return
    if status is None:
        installed, text, icon = _installed(entry), "checking...", 'TIME'
        # The periodic check may belong to an older hub copy that keeps no status: ask this
        # copy's check once (not from draw itself: a timer runs it right after).
        if not getattr(st, "status_requested", False):
            st.status_requested = True
            bpy.app.timers.register(lambda: (_check_all(), None)[1], first_interval=0.1)
    else:
        installed, _, state = status
        text, icon = {"ok": ("up to date", 'CHECKMARK'),
                      "local": ("local install", 'INFO'),
                      "error": ("check failed", 'ERROR')}[state]
    row.label(text="%s %s, %s" % (entry["label"], installed or "?", text), icon=icon)
    row.operator("liok.hub_check", text="", icon='FILE_REFRESH', emboss=False)
    row.operator("liok.hub_reload", text="", icon='LOOP_BACK', emboss=False).target = addon_id


def _installed(entry):
    up = _updater(entry)
    try:
        return up.info(entry["module"])["installed"] if up else None
    except Exception:
        return None


_CLASSES = (LIOK_OT_hub_tab, LIOK_OT_hub_update, LIOK_OT_hub_enable, LIOK_OT_hub_reload, LIOK_OT_hub_copy_error, LIOK_OT_hub_check, LIOK_OT_hub_more_install,
            LIOK_OT_hub_more_refresh, LIOK_PT_hub, LIOK_PT_hub_more)


def _install_classes(st):
    for c in st.classes:
        try:
            bpy.utils.unregister_class(c)
        except (RuntimeError, ValueError, AttributeError):
            pass
    for c in _CLASSES:
        try:
            bpy.utils.unregister_class(c)   # a copy left by a failed reload
        except (RuntimeError, ValueError, AttributeError):
            pass
        bpy.utils.register_class(c)
    st.classes, st.hub_version = _CLASSES, HUB_VERSION


def register_addon(addon_id, label, module, icon='NONE', order=100, can_update=None, reload=None):
    st = _state()
    try:
        stamp = _disk_stamp(module)
    except Exception:
        stamp = None
    st.addons[addon_id] = {"label": label, "module": module, "icon": icon, "order": order,
                           "can_update": can_update, "reload": reload, "loaded_stamp": stamp}
    if HUB_VERSION > st.hub_version:
        _install_classes(st)
    if not bpy.app.background and getattr(st, "timer", None) is None:
        st.timer = _tick  # one timer for the whole collection, whichever copy started it
        bpy.app.timers.register(_tick, first_interval=CHECK_DELAY_S, persistent=True)


def unregister_addon(addon_id):
    st = _state()
    st.addons.pop(addon_id, None)
    st.updates.pop(addon_id, None)
    st.status.pop(addon_id, None)
    st.deferred.pop(addon_id, None)
    if st.addons and getattr(st, "scanned", False):
        _request_scan(0.5)  # an add-on turned off may now show in the "turned off" list
    if not st.addons:
        for c in st.classes:
            try:
                bpy.utils.unregister_class(c)
            except (RuntimeError, ValueError, AttributeError):
                pass
        st.classes, st.hub_version = (), 0
        timer = getattr(st, "timer", None)
        if timer is not None and bpy.app.timers.is_registered(timer):
            bpy.app.timers.unregister(timer)
        st.timer = None
